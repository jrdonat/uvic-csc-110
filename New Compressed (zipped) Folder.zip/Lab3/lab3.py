import doctest


def get_longer(string_a: str, string_b: str) -> str:
    """
    This function returns the longer of two strings

    Example
    >>> get_longer("a", "aa")
    'aa'
    >>> get_longer("aa", "a")
    'aa'
    >>> get_longer("a", "b")
    'a'

    :param string_a: first string to search for longer
    :param string_b: second string to search for longer
    :return: returns the longer of the two strings
    """
    return string_b if len(string_b) > len(string_a) else string_a


def get_tax(food_cost: float, alcohol_cost: float) -> float:
    """
    This function returns the tax on food and alcohol

    Example:
    >>> get_tax(20,15)
    3.25
    >>> get_tax(0,0)
    0.0
    >>> get_tax(100,100)
    20.0
    >>> get_tax(100,0)
    5.0
    >>> get_tax(0,100)
    15.0

    :param food_cost: the cost of food
    :param alcohol_cost: the cost of alcohol
    :return: returns the tax on food and alcohol
    """
    gst_tax_rate = 0.05
    pst_tax_rate = 0.10

    return ((food_cost * gst_tax_rate) +
            (alcohol_cost * gst_tax_rate) +
            (alcohol_cost * pst_tax_rate))


def get_bill_share(food_cost: float, alcohol_cost: float, num_people: int) -> float:
    """
    This function returns the bill share for each person

    Example:
    >>> get_bill_share(20,15,5)
    7.65
    >>> get_bill_share(0,0,1)
    0.0
    >>> get_bill_share(100,100,10)
    22.0

    :param food_cost: the cost of food
    :param alcohol_cost: the cost of alcohol
    :param num_people: the number of people
    :return: returns the bill share for each person
    """
    return (food_cost + alcohol_cost + get_tax(food_cost, alcohol_cost)) / num_people
