import doctest


def get_biggest(int_a: int, int_b: int, int_c: int) -> int:
    """
    function to return the biggest of three integers

    Example
    >>> get_biggest(1, 2, 3)
    3
    >>> get_biggest(3, 2, 1)
    3
    >>> get_biggest(2, 3, 1)
    3
    >>> get_biggest(1, 1, 1)
    1

    :param int_a: first int to search for biggest
    :param int_b: second int to search for biggest
    :param int_c: third int to search for biggest
    :return:
    """
    ints = (int_a, int_b, int_c)
    biggest = int_a

    for i in ints:
        if i > biggest:
            biggest = i

    return biggest


def get_smallest(int_a: int, int_b: int, int_c: int) -> int:
    """
    This function returns the smallest of three integers

    Example
    >>> get_smallest(1, 2, 3)
    1
    >>> get_smallest(3, 2, 1)
    1
    >>> get_smallest(2, 3, 1)
    1
    >>> get_smallest(1, 1, 1)
    1

    :param int_a: first int to search for smallest
    :param int_b: second int to search for smallest
    :param int_c: third int to search for smallest
    :return:
    """
    ints = (int_a, int_b, int_c)
    smallest = int_a

    for i in ints:
        if i < smallest:
            smallest = i

    return smallest


def is_multiple_of(n1: int, n2: int) -> bool:
    """
    Function to print whether a number is a multiple of the other

    Example:
    >>> is_multiple_of(0,0)
    True
    >>> is_multiple_of(9,0)
    False
    >>> is_multiple_of(0,9)
    True
    >>> is_multiple_of(4,2)
    True
    >>> is_multiple_of(5,7)
    False

    :param n1: number to have multiples checked against
    :param n2: check if this number is a multiple of n1
    :return: True if n2 is a multiple of n1, False otherwise
    """

    return n1 == n2 or (n2 != 0 and (n1 % n2 == 0))


def is_biggest_multiple_of_smallest(int_a: int, int_b: int, int_c: int) -> bool:
    """
    This function returns whether the biggest number is a multiple of the smallest number

    Examples:
    >>> is_biggest_multiple_of_smallest(1, 2, 3)
    True
    >>> is_biggest_multiple_of_smallest(8, 2, 4)
    True
    >>> is_biggest_multiple_of_smallest(7, 3, 11)
    False
    >>> is_biggest_multiple_of_smallest(1, 1, 1)
    True
    >>> is_biggest_multiple_of_smallest(0, 0, 0)
    True
    >>> is_biggest_multiple_of_smallest(0, 0, 1)
    False

    :param int_a:
    :param int_b:
    :param int_c:
    :return:
    """
    return is_multiple_of(get_biggest(int_a, int_b, int_c), get_smallest(int_a, int_b, int_c))


def maximum(float_a: float, float_b: float) -> float:
    """
    This function returns the maximum of two floats

    Examples:
    >>> maximum(0.0, 0.0)
    0.0
    >>> maximum(0.0, 1.0)
    1.0
    >>> maximum(1.0, 0.0)
    1.0
    >>> maximum(1.0, 1.0)
    1.0

    :param float_a: the first float to compare
    :param float_b: the second float to compare
    :return: returns the maximum of the two floats
    """
    return float_b if float_b > float_a else float_a


def display_charges(item_price: float, tax_rate: int, is_member: bool, discount_code: str, country: str):
    """
    This function displays the charges for a purchase

    Examples:
    >>> display_charges(0, 0, False, 'invalid', 'Afghanistan')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(6.69, 14, False, 'FIRST_PURCHASE', 'Belgium')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.67
    total charge: $ 0.67
    >>> display_charges(2.32, 11, False, 'NO_DISCOUNT', 'Czech Republic')
    price: $ 2.32
    tax: $ 0.26
    shipping: $ 0.23
    total charge: $ 2.81
    >>> display_charges(2.32, 11, True, 'NO_DISCOUNT', 'Czech Republic')
    price: $ 2.32
    tax: $ 0.26
    shipping: $ 0.00
    total charge: $ 2.58
    >>> display_charges(2.32, 11, False, 'NO_DISCOUNT', 'Canada')
    price: $ 2.32
    tax: $ 0.26
    shipping: $ 0.00
    total charge: $ 2.58
    >>> display_charges(2.32, 11, True, 'NO_DISCOUNT', 'Canada')
    price: $ 2.32
    tax: $ 0.26
    shipping: $ 0.00
    total charge: $ 2.58
    >>> display_charges(2.32, 11, False, 'FIRST_PURCHASE', 'Czech Republic')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.23
    total charge: $ 0.23
    >>> display_charges(19.27, 9, False, 'NO_DISCOUNT', 'Chile')
    price: $ 19.27
    tax: $ 1.73
    shipping: $ 1.93
    total charge: $ 22.93
    >>> display_charges(19.27, 9, True, 'NO_DISCOUNT', 'Chile')
    price: $ 19.27
    tax: $ 1.73
    shipping: $ 0.00
    total charge: $ 21.00
    >>> display_charges(19.27, 9, False, 'NO_DISCOUNT', 'Canada')
    price: $ 19.27
    tax: $ 1.73
    shipping: $ 0.00
    total charge: $ 21.00
    >>> display_charges(19.27, 9, True, 'NO_DISCOUNT', 'Canada')
    price: $ 19.27
    tax: $ 1.73
    shipping: $ 0.00
    total charge: $ 21.00
    >>> display_charges(19.27, 9, False, 'FIRST_PURCHASE', 'Chile')
    price: $ 9.27
    tax: $ 0.83
    shipping: $ 1.93
    total charge: $ 12.03
    >>> display_charges(19.27, 9, True, 'FIRST_PURCHASE', 'Chile')
    price: $ 9.27
    tax: $ 0.83
    shipping: $ 0.00
    total charge: $ 10.10
    >>> display_charges(19.27, 9, False, 'FIRST_PURCHASE', 'Canada')
    price: $ 9.27
    tax: $ 0.83
    shipping: $ 0.00
    total charge: $ 10.10
    >>> display_charges(19.27, 9, True, 'FIRST_PURCHASE', 'Canada')
    price: $ 9.27
    tax: $ 0.83
    shipping: $ 0.00
    total charge: $ 10.10
    >>> display_charges(19.27, 9, False, 'FREQUENT_BUYER', 'Chile')
    price: $ 19.27
    tax: $ 1.73
    shipping: $ 1.93
    total charge: $ 22.93
    >>> display_charges(0, 3, False, 'NO_DISCOUNT', 'Syria')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(0, 3, True, 'NO_DISCOUNT', 'Syria')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(0, 3, False, 'NO_DISCOUNT', 'Canada')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(0, 3, True, 'NO_DISCOUNT', 'Canada')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(0, 3, False, 'FIRST_PURCHASE', 'Syria')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(2, 9, False, 'NO_DISCOUNT', 'Azerbaijan')
    price: $ 2.00
    tax: $ 0.18
    shipping: $ 0.20
    total charge: $ 2.38
    >>> display_charges(2, 9, True, 'NO_DISCOUNT', 'Azerbaijan')
    price: $ 2.00
    tax: $ 0.18
    shipping: $ 0.00
    total charge: $ 2.18
    >>> display_charges(2, 9, False, 'NO_DISCOUNT', 'Canada')
    price: $ 2.00
    tax: $ 0.18
    shipping: $ 0.00
    total charge: $ 2.18
    >>> display_charges(2, 9, True, 'NO_DISCOUNT', 'Canada')
    price: $ 2.00
    tax: $ 0.18
    shipping: $ 0.00
    total charge: $ 2.18
    >>> display_charges(2, 9, False, 'FIRST_PURCHASE', 'Azerbaijan')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.20
    total charge: $ 0.20
    >>> display_charges(10, 10, False, 'NO_DISCOUNT', 'Nigeria')
    price: $ 10.00
    tax: $ 1.00
    shipping: $ 1.00
    total charge: $ 12.00
    >>> display_charges(10, 10, True, 'NO_DISCOUNT', 'Nigeria')
    price: $ 10.00
    tax: $ 1.00
    shipping: $ 0.00
    total charge: $ 11.00
    >>> display_charges(10, 10, False, 'NO_DISCOUNT', 'Canada')
    price: $ 10.00
    tax: $ 1.00
    shipping: $ 0.00
    total charge: $ 11.00
    >>> display_charges(10, 10, True, 'NO_DISCOUNT', 'Canada')
    price: $ 10.00
    tax: $ 1.00
    shipping: $ 0.00
    total charge: $ 11.00
    >>> display_charges(10, 10, True, 'FIRST_PURCHASE', 'Nigeria')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(10, 10, False, 'FIRST_PURCHASE', 'Canada')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(10, 10, True, 'FIRST_PURCHASE', 'Canada')
    price: $ 0.00
    tax: $ 0.00
    shipping: $ 0.00
    total charge: $ 0.00
    >>> display_charges(10, 10, False, 'FREQUENT_BUYER', 'Nigeria')
    price: $ 10.00
    tax: $ 1.00
    shipping: $ 1.00
    total charge: $ 12.00
    """
    subtotal = get_discounted_price(discount_code, item_price, is_member)
    tax_cost = subtotal * (tax_rate / 100)
    shipping_cost = get_shipping(is_member, country, item_price)

    print(f'price: $ {subtotal:.2f}\n'
          f'tax: $ {tax_cost:.2f}\n'
          f'shipping: $ {shipping_cost:.2f}\n'
          f'total charge: $ {subtotal + tax_cost + shipping_cost :.2f}')


def get_shipping(is_member: bool, country: str, item_price: float) -> float:
    """
    This function returns the shipping cost for a purchase

    Examples:
    >>> get_shipping( True, 'canada',10.0)
    0
    >>> get_shipping(False, 'canada', 10.0)
    0
    >>> get_shipping(True, 'usa', 10.0)
    0
    >>> get_shipping(False, 'usa', 10.0)
    1.0
    >>> get_shipping(True, 'mexico', 10.0)
    0
    >>> get_shipping(False, 'mexico', 10.0)
    1.0

    :param country:
    :param is_member:
    :param item_price:
    :return:
    """
    shipping_rate = 0.1
    shipping_cost = item_price * shipping_rate

    if is_member or country.lower() == "canada":
        shipping_cost = 0

    return shipping_cost


def get_discount(discount_code: str, is_member: bool) -> float:
    """
    This function returns the discount amount for a purchase

    Examples:
    >>> get_discount('FREQUENT_BUYER', True)
    2
    >>> get_discount('FREQUENT_BUYER', False)
    0
    >>> get_discount('FIRST_PURCHASE', True)
    10
    >>> get_discount('FIRST_PURCHASE', False)
    10
    >>> get_discount('invalid', True)
    0
    >>> get_discount('invalid', False)
    0

    :param discount_code: the discount code to apply
    :param is_member: Is the customer a member
    :return: Returns the discount amount
    """
    discount_amount = 0

    if discount_code == 'FREQUENT_BUYER' and is_member:
        discount_amount = 2
    elif discount_code == 'FIRST_PURCHASE':
        discount_amount = 10

    return discount_amount


def get_discounted_price(discount_code: str, item_price: float, is_member: bool) -> float:
    """
    This function returns the discounted price for a purchase

    Examples:
    >>> get_discounted_price('FREQUENT_BUYER', 10.0, True)
    8.0
    >>> get_discounted_price('FREQUENT_BUYER', 10.0, False)
    10.0
    >>> get_discounted_price('FIRST_PURCHASE', 10.0, True)
    0
    >>> get_discounted_price('FIRST_PURCHASE', 10.0, False)
    0
    >>> get_discounted_price('invalid', 10.0, True)
    10.0
    >>> get_discounted_price('invalid', 10.0, False)
    10.0
    >>> get_discounted_price('FREQUENT_BUYER', 0.0, True)
    0
    >>> get_discounted_price('FREQUENT_BUYER', 0.0, False)
    0
    >>> get_discounted_price('FIRST_PURCHASE', 0.0, True)
    0
    >>> get_discounted_price('FIRST_PURCHASE', 0.0, False)
    0

    :param item_price: Price of the item
    :param discount_code: Discount code to apply
    :param is_member: Is the customer a member
    :return: Returns the discounted price
    """
    discount_amount = get_discount(discount_code, is_member)
    return maximum(0, item_price - discount_amount)
