def print_my_info():
    """Prints personal information assigned to local variables to shell
    E.g.
    My name is Dryden
    My favourite number is 420
    I am 18 years old
    Here is some math: 420/18 is 23.33

    Example:
    >>>print_my_info()
    My name is Dryden
    My favourite number is 420
    I am 18 years old
    Here is some math: 420/18 is 23.33
    """

    name = 'Dryden'
    age = 18
    favourite_number = 420

    print(f'My name is {name}\n'
          f'My favourite number is {favourite_number}\n'
          f'I am {age} years old\nHere is some math: '
          f'{favourite_number}/{age} is {favourite_number / age:.2f}')


def print_sum():
    """
    Prints the sum of the two floats assigned to the local variables

    Example:
    >>>print_sum()
    105.60000000000001
    """

    input_float_a = 23.2
    input_float_b = 82.4

    print(input_float_a + input_float_b)


print_my_info()
print_sum()
