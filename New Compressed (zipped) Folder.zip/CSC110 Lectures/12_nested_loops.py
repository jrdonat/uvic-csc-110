import doctest


'''
Q1. Design a function that takes a string and 2 numbers
representing height and width.
The function should print a rectangular pattern using the given string
that is of dimension width by height.
You can assume that height and width are not negative and the string is not empty
Example. if the string is '*#' and height is 4 and width is 3, it should print:
*#*#*#
*#*#*#
*#*#*#
*#*#*#
You must not use the * operator to repeat your string.
'''


'''
Q2. Design a function that will take a number representing height and it
should print a right angle triangle using '*'s that is of the given height.
You can assume that size is greater than or equal to 0
Examples:
if ht is 2, prints:
*
**
if ht is 3, prints:
*
**
***
'''


'''
Q3. Design a fucntion that takes a non-negative number that represents a size
and prints a number pattern according to the size.
You can assume that size is greater than or equal to 0
Examples:
if the size is 3 it prints...
3
32
321
if the size is 5 it prints...
5
54
543
5432
54321
'''


'''
Q4. Design a function that will take a number representing height and it
should print an isosceles triangle using '*'s that is of the given height.
You can assume that size is greater than or equal to 0
TIP: to get the stars to appear centered, think about how many space (' ')
characters to print on a row before you print the * characters.
Examples:
if ht is 2, prints:
 *
***
if ht is 3, prints:
  *
 ***
*****
'''

'''
Q5. Design a function that will take a number representing height and it
should print a diamond using '*'s that is of the given height.
You can assume that size is greater than or equal to 0
Examples:
if ht is 2, prints:
 *
***
 *
if ht is 3, prints:
  *
 ***
*****
 ***
  *
'''
