'''
Q1. Design a function that will take a whole number and
prints the number and prints whether it is odd or not
'''


'''
Q2. Design a function that takes two numbers and prints
the smallest value.  Do not use the builtin min function.
'''


'''
Q3. Design a function that takes one argument: a person's age
and determines and prints the cost of
riding the bus based on that given age.
Your function should assume age is not negative.

If age is less than 18, the cost is $1.50.
If age is 65 or more, the cost is $2.00.
For all other values of age, the cost is $2.50.
'''


'''
Q4. Design a function that takes a number within the range of 1 through 10.
The function should assume it will only be called with numbers 1 to 10.
The function should display the Roman numeral version of that number.
The following list shows the Roman numerals for the numbers 1 through 10:

Number:	Roman Numeral
1	I
2	II
3	III
4	IV
5	V
6	VI
7	VII
8	VIII
9	IX
10	X
'''
