import doctest

'''
Q1. Design a function that takes an integer n and prints
 the squares of numbers from 0 to n separated by commas.
Your function should assume n is not negative.
'''


'''
Q2. Design a function that takes an integer n and returns
the sum of the squares of numbers from 0 to n.
Your function should assume n is not negative.
'''


'''
Q3. Design a function that takes an integer n and returns
a string with the squares of all the numbers from 0 to limit inclusive,
where numbers are separated by commas.
'''


'''
Q4. Design a function that takes an integer n and prints
the number n down to 1 followed by 'BLASTOFF!'
Your function should assume n is greater than 0.
'''


'''
Q5. Design a function that takes an integer n and a string and
prints that string n times with no additional spaces or newlines.
Your function should assume n is not negative
You cannot use the * operator.
'''


'''
Q6. Design a function that takes an integer n and a string and
returns a new string that has the given string repeated n times
with no additional spaces or newlines.
Your function should assume n is not negative
You cannot use the * operator.
'''
